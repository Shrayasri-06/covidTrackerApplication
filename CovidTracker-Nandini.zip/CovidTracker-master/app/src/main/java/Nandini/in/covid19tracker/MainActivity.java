package Nandini.in.covid19tracker;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import Nandini.in.covid19tracker.api.ApiUtilities;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private ArrayList<CountryData> list;
    private TextView totalConfirmCase, totalActive, totalRecovered, totalDeath, totalTests;
    private TextView todayConfirmCase, todayRecovered, todayDeath, countryName;
    private PieChart pieChart;
    ProgressDialog dialog;
    private GridLayout container;
    private String country = "India";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            if (getIntent().getStringExtra("country") != null)
            country = getIntent().getStringExtra("country");


        list = new ArrayList<>();

        init();
        countryName.setText(country);

        countryName.setOnClickListener(v -> startActivity(new Intent(this, CountryActivity.class)));

        ApiUtilities.getApiInterface().getCountryData()
                .enqueue(new Callback<List<CountryData>>() {
                    @Override
                    public void onResponse(Call<List<CountryData>> call, Response<List<CountryData>> response) {
                        list.addAll(response.body());
                        Log.d("RESPONSEBODY", list.get(0).getCountry());
                        container.setVisibility(View.VISIBLE);
                        dialog.dismiss();

                        for (int i = 0; i < list.size(); i++) {
                            if (list.get(i).getCountry().equals(country)) {
//                                Toast.makeText(MainActivity.this, list.get(i).getCountry(), Toast.LENGTH_SHORT).show();

                                int confirm = Integer.parseInt(list.get(i).getCases());
                                int active = Integer.parseInt(list.get(i).getActive());
                                int recovered = Integer.parseInt(list.get(i).getRecovered());
                                int death = Integer.parseInt(list.get(i).getDeaths());

                                totalConfirmCase.setText(NumberFormat.getInstance().format(confirm));
                                totalActive.setText(NumberFormat.getInstance().format(active));
                                totalRecovered.setText(NumberFormat.getInstance().format(recovered));
                                totalDeath.setText(NumberFormat.getInstance().format(death));

                                totalTests.setText(NumberFormat.getInstance().format(Integer.parseInt(list.get(i).getTests())));
                                todayConfirmCase.setText("( +"+NumberFormat.getInstance().format(Integer.parseInt(list.get(i).getTodayCases()))+" )");
//                                todayActive.setText(NumberFormat.getInstance().format(Integer.parseInt(list.get(i).getac())));
                                todayRecovered.setText("( +"+NumberFormat.getInstance().format(Integer.parseInt(list.get(i).getTodayRecovered()))+" )");
                                todayDeath.setText("( +"+NumberFormat.getInstance().format(Integer.parseInt(list.get(i).getTodayDeaths()))+" )");

                                setTime(list.get(i).getUpdated());

                                pieChart.addPieSlice(new PieModel("Confirmed", confirm, getResources().getColor(R.color.yellow)));
                                pieChart.addPieSlice(new PieModel("Active", active, getResources().getColor(R.color.blue_pie)));
                                pieChart.addPieSlice(new PieModel("Recovered", recovered, getResources().getColor(R.color.green_pie)));
                                pieChart.addPieSlice(new PieModel("Death", death, getResources().getColor(R.color.red_pie)));

                                pieChart.startAnimation();

                            }

                        }
                    }

                    @Override
                    public void onFailure(Call<List<CountryData>> call, Throwable t) {
                        Toast.makeText(MainActivity.this, "Error : " + t.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });


    }

    private void setTime(String s) {

        DateFormat formatter = new SimpleDateFormat("MMM dd, yyyy");

        long milliSeconds= Long.parseLong(s);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);

        TextView tv = findViewById(R.id.lastUpdated);
        tv.setText("Last updated at "+formatter.format(calendar.getTime()));
    }

    private void init() {

        dialog = new ProgressDialog(this);
        dialog.setMessage("Loading...");
        dialog.setCancelable(false);
        dialog.show();

        countryName = findViewById(R.id.countryName);
        container = findViewById(R.id.container);
        totalConfirmCase = findViewById(R.id.totalConfirmCase);
        totalActive = findViewById(R.id.totalActive);
        totalRecovered = findViewById(R.id.totalRecovered);
        totalDeath = findViewById(R.id.totalDeath);
        todayConfirmCase = findViewById(R.id.todayConfirmCase);
        totalTests = findViewById(R.id.totalTests);
//        todayActive = findViewById(R.id.todayActive);
        todayRecovered = findViewById(R.id.todayRecovered);
        todayDeath = findViewById(R.id.todayDeath);
        pieChart = findViewById(R.id.piechart);
        pieChart.clearChart();

        container.setVisibility(View.GONE);

    }
}