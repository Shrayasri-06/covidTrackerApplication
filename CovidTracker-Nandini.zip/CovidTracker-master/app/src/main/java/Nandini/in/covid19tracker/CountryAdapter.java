package Nandini.in.covid19tracker;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.jetbrains.annotations.NotNull;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.CountryViewHolder> {

    private Context context;
    private List<CountryData> data;

    public CountryAdapter(Context context, List<CountryData> data) {
        this.context = context;
        this.data = data;
    }

    public void filteredList(ArrayList<CountryData> filterlist) {
        data = filterlist;
        notifyDataSetChanged();
    }

    @NonNull
    @org.jetbrains.annotations.NotNull
    @Override
    public CountryViewHolder onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup parent, int viewType) {
        return new CountryViewHolder(LayoutInflater.from(context).inflate(R.layout.country_item_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull @org.jetbrains.annotations.NotNull CountryAdapter.CountryViewHolder holder, int position) {

        CountryData item = data.get(position);
        holder.countryName.setText(item.getCountry());
        holder.sno.setText(String.valueOf(position+1));
        holder.countryCase.setText(NumberFormat.getInstance().format(Integer.parseInt(item.getCases())));

        Map<String, String> obj = item.getCountryInfo();
        Log.d("COUNTRYINFO", "COUNTRYINFO: "+obj.get("flag"));
        Glide.with(context).load(obj.get("flag")).into(holder.imageView);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, MainActivity.class);
            intent.putExtra("country", item.getCountry());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class CountryViewHolder extends RecyclerView.ViewHolder {

        private TextView sno, countryName, countryCase;
        private ImageView imageView;

        public CountryViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            sno = itemView.findViewById(R.id.sno);
            countryName = itemView.findViewById(R.id.countryName);
            countryCase = itemView.findViewById(R.id.countryCases);
            imageView = itemView.findViewById(R.id.countryImage);
        }
    }
}
